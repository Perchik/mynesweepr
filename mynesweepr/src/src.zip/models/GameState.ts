export type GameButtonState = "mousedown" | "win" | "lose" | "none";

export type GameState = "inprogress" | "win" | "lose" | "none";
